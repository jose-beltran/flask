bars = document.querySelector(".bars");
bars.onclick =function(){
    navBar = document.querySelector(".nav-bar");
    navBar.classList.toggle("active")
}